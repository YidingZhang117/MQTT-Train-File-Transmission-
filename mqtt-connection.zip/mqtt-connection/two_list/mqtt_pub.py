import paho.mqtt.publish as publish

HOST = "127.0.0.1"
PORT = 1883

if __name__ == '__main__':
    a = [1,2,3,4,5]
    b = [6,7,8,9,10]
    all_list = {"list1":a, "list2":b}
    for key, l in all_list.items():
        msgs = []
        l.reverse()
        for num in l:
            msgs.append({'topic':"sensor", 'payload': key+"###"+str(num)})
        print(msgs)
        publish.multiple(msgs, hostname=HOST, port=PORT)